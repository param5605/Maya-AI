# Maya Android starter

Maya is a Kotlin Android starter app with a casual, friend-like chat personality, text-to-speech, Android speech-recognition handoff, a few local commands, and an optional Gemini API connection.

## Important status
This is a **starter project**, not a finished production APK. It does not yet include a custom always-on "Maya" wake-word detector or a background microphone service. The Talk button invokes Android's speech-recognition UI. Always-on wake-word support needs a dedicated on-device wake-word engine, a foreground service, explicit microphone permissions, and testing on the target OPPO device.

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s). It uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.

A cloud Android builder can also be used, but it must support Gradle/Android SDK and allow downloading the resulting APK.

## Gemini key
The starter has an optional API-key field to help test connectivity. It is not saved to disk, but an API key entered directly in a client app can still be exposed to anyone who can inspect the app or its network traffic. For a public or long-term release, route requests through a backend that keeps the API key secret. Model availability and free-tier limits may change.

## Requirements
- Android SDK 35
- JDK 17
- Internet access for Gemini requests
- Microphone permission for speech recognition

## Current starter features
- Casual Maya replies and friendly tone
- Text chat
- Android speech-recognition handoff
- Android text-to-speech with en-IN locale preference
- Simple local commands (time and opening YouTube)
- Optional Gemini API request

## Not included yet
- Always-on wake word "Maya"
- Lock-screen/background wake-word reliability
- Secure backend for AI keys
- Persistent conversation memory
- Robust app-control/permissions flow
- Production testing and release signing
