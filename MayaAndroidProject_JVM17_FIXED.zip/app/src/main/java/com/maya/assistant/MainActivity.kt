package com.maya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import android.view.Gravity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val speechRequest = 4102
    private val micRequest = 4103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
        }
        append("Maya", "Yup? 💙 I'm here. What's up?")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(12, 10, 35), Color.rgb(35, 15, 66), Color.rgb(9, 20, 48))
            )
        }
        val title = TextView(this).apply {
            text = "M A Y A"
            textSize = 30f
            setTextColor(Color.rgb(220, 205, 255))
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "your AI friend 💙"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 22)
        }
        chat = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(16, 16, 16, 16)
        }
        val scroll = ScrollView(this).apply {
            addView(chat)
            background = rounded(Color.argb(45, 255, 255, 255), 22f)
        }
        input = EditText(this).apply {
            hint = "Say something to Maya..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(14, 8, 14, 8)
            background = rounded(Color.argb(55, 255, 255, 255), 18f)
        }
        val send = Button(this).apply {
            text = "Send 💬"
            setOnClickListener {
                val message = input.text.toString().trim()
                if (message.isNotEmpty()) {
                    input.setText("")
                    handleMessage(message)
                }
            }
        }
        val listen = Button(this).apply {
            text = "🎙 Talk to Maya"
            setOnClickListener { startListening() }
        }
        val key = EditText(this).apply {
            hint = "Optional Gemini API key (not saved)"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            inputType = 129
            background = rounded(Color.argb(35, 255, 255, 255), 18f)
            tag = "api_key"
        }
        val note = TextView(this).apply {
            text = "Starter build • Internet AI needs a provider key. Never share your key."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 12, 0, 0)
        }
        root.addView(title)
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 12 })
        root.addView(send)
        root.addView(listen)
        root.addView(key, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 8 })
        root.addView(note)
        setContentView(root)
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(1, Color.argb(75, 210, 190, 255))
    }

    private fun append(who: String, message: String) {
        chat.append("$who: $message\n\n")
        status.text = if (who == "Maya") "here for you 💙" else "listening..."
    }

    private fun handleMessage(message: String) {
        append("You", message)
        val lower = message.lowercase(Locale.ROOT)
        when {
            lower.contains("what time") || lower == "time" -> {
                val answer = "It's ${java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())}, bro."
                append("Maya", answer); speak(answer)
            }
            lower.contains("open youtube") -> {
                val launch = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (launch != null) {
                    append("Maya", "Yup, opening YouTube!"); speak("Yup, opening YouTube!")
                    startActivity(launch)
                } else {
                    append("Maya", "I couldn't find YouTube on this phone."); speak("I couldn't find YouTube on this phone.")
                }
            }
            lower.contains("hello") || lower.contains("hi") -> reply("Yooo! What's up? 😄")
            lower.contains("bored") -> reply("Brooo 😂 wanna talk, play a game, or find something fun to do?")
            lower.contains("bad day") || lower.contains("sad") -> reply("Aw bro 🫂 wanna tell me what happened?")
            lower.contains("who are you") -> reply("I'm Maya, your AI buddy. No formal stuff here 😎")
            else -> {
                val keyField = findViewById<LinearLayout>(android.R.id.content)
                    .let { findKeyField(it) }
                val key = keyField?.text?.toString()?.trim().orEmpty()
                if (key.isBlank()) {
                    reply("Hmm, I need an AI brain connected for that one 😅 Add a Gemini API key below, or we can set up a safer cloud connection later.")
                } else {
                    askGemini(key, message)
                }
            }
        }
    }

    private fun findKeyField(view: android.view.View): EditText? {
        if (view is EditText && view.hint?.toString()?.startsWith("Optional Gemini") == true) return view
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                val found = findKeyField(view.getChildAt(i))
                if (found != null) return found
            }
        }
        return null
    }

    private fun reply(text: String) {
        append("Maya", text)
        speak(text)
    }

    private fun askGemini(key: String, prompt: String) {
        append("Maya", "Gimme a sec... 💭")
        thread {
            val result = try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject()
                    .put("system_instruction", JSONObject().put("parts", org.json.JSONArray().put(
                        JSONObject().put("text", "You are Maya, the user's casual AI friend. Talk naturally, warmly, playfully, and simply. Use short replies when appropriate. Avoid professional or robotic greetings. You may call the user bro sometimes, but don't overdo it.")
                    )))
                    .put("contents", org.json.JSONArray().put(
                        JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", prompt)))
                    )).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) {
                    "Oops, the AI service returned an error. Check the key or model availability."
                } else {
                    val json = JSONObject(response)
                    json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                }
            } catch (e: Exception) {
                "I couldn't reach my AI brain just now 😅 Check your internet and try again."
            }
            runOnUiThread { append("Maya", result); speak(result) }
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Maya")
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: Exception) { Toast.makeText(this, "Speech recognition isn't available.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated by Android, retained for broad compatibility in this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) handleMessage(spoken)
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "maya_reply")
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts.language = Locale("en", "IN")
            tts.setSpeechRate(0.96f)
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
